# Peg-Leg Greg — NotebookLM Sources

Upload the `PLG_BOOK_*.md` files in this folder to one NotebookLM notebook.

Books I and II are whole-Book sources. Book III onward is split by the current Act structure so individual uploads stay manageable as the manuscript grows.

`PLG_STRUCTURE_MAP.md` is optional. Add it when you want NotebookLM to know the intended Book/Act boundaries explicitly. Leave it out for a completely blind structural read.

These are deliberately **manuscript-only** sources. Do not add `MANUSCRIPT_STATE`, `STORY_NORTH_STAR`, plot notes, or other project-brain files for the first cold-read experiment.

Current exported endpoint: **Chapter 485**.

Current manuscript source files: **9**.

Suggested first chat prompt:

> Read Peg-Leg Greg broadly across the complete manuscript before answering. Treat this as a serious long-form fantasy novel and come in as an engaged reader and book-club partner, not as someone whose job is to encourage me.
>
> I don't want you to infer the novel from chapter titles or project notes. Ground your interpretation in the actual prose, scenes, dialogue, character behavior, and changes across the manuscript.
>
> Look longitudinally. Pay attention to changes that take dozens or hundreds of chapters to become visible. Surprise me with patterns, strengths, weaknesses, themes, character developments, contradictions, and things I may have written without consciously realizing it.
>
> Don't automatically criticize slowness, mundane life, or repetition, but don't protect them from criticism either.
>
> I told you I dabbled in writing and then showed you Peg-Leg Greg. You've now read the actual thing. **What do you think I made?**
